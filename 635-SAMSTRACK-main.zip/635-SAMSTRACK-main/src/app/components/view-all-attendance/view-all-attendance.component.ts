import { Component } from '@angular/core';

@Component({
  selector: 'app-view-all-attendance',
  templateUrl: './view-all-attendance.component.html',
  styleUrls: ['./view-all-attendance.component.css']
})
export class ViewAllAttendanceComponent {

}
