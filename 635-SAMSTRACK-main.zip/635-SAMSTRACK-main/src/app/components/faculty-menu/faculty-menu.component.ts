import { Component } from '@angular/core';

@Component({
  selector: 'app-faculty-menu',
  templateUrl: './faculty-menu.component.html',
  styleUrls: ['./faculty-menu.component.css']
})
export class FacultyMenuComponent {

}
